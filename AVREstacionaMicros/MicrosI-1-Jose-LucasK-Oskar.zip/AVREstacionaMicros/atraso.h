/*
 * atraso.h
 *
 * Created: 29/10/2019 13:55:47
 *  Author: Lucas
 */ 


#ifndef ATRASO_H_
#define ATRASO_H_

void atrasoms(unsigned int ms);
void atrasous(unsigned int us);

#endif /* ATRASO_H_ */