
/*
 * rrelogio.h
 *
 * Created: 31/10/2019 22:47:55
 *  Author: Oskar
 */ 


#ifndef RRELOGIO_H_
#define RRELOGIO_H_

extern DataHora relogio;
void timer1_config();

#endif /* RRELOGIO */